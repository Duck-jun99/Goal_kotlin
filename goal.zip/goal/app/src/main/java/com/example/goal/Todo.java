package com.example.goal;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.ArrayList;


@Entity
public class Todo {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String Big_Goal;
    private ArrayList<String> Small_Goal;
    private int stage;

    public Todo(String Big_Goal, ArrayList<String> Small_Goal) {
        this.Big_Goal = Big_Goal;
        this.Small_Goal = Small_Goal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBig_Goal() {
        return Big_Goal;
    }

    public void setBig_Goal(String Big_Goal) {
        this.Big_Goal = Big_Goal;
    }

    public ArrayList<String> getSmall_Goal(){
        return Small_Goal;
    }

    public void setSmall_Goal(ArrayList<String> Small_Goal){
        this.Small_Goal=Small_Goal;
    }

    public int getStage(){return stage;}

    public void setStage(int stage) {this.stage = stage;}

    @Override
    public String toString() {
        return Big_Goal + Small_Goal;
    }


    /*private String title;

    public Todo(String title) {
        this.title = title;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Todo{");
        sb.append("id=").append(id);
        sb.append(", title=' ").append(title).append('\'');
        sb.append('}');
        return sb.toString();
    }*/
}
