package com.example.goal;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.ArrayList;

public class MakeGoal extends AppCompatActivity {

    ArrayList<String> small_goal_data = new ArrayList<String>();
    ArrayList<String> view_small_goal_data = new ArrayList<>();

    EditText et_small_goal;
    EditText et_big_goal;
    Button btn_plus_small_goal;
    Button btn_del_small_goal;
    Button btn_save_goal;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.make_goal);

        ListView listView2 = (ListView) findViewById(R.id.listview2);


        et_big_goal = findViewById(R.id.et_big_goal);
        et_small_goal = findViewById(R.id.et_small_goal);
        btn_plus_small_goal = findViewById(R.id.btn_plus_small_goal);
        btn_del_small_goal = findViewById(R.id.btn_del_small_goal);
        btn_save_goal = findViewById(R.id.btn_save_goal);


        final AppDatabase db = Room.databaseBuilder(this, AppDatabase.class, "Goal_db")
                .allowMainThreadQueries().build();
        //allowMainThreadQueries()는 메인스레드에서 강제로 작동하게 해줌. 나중엔 백그라운드 스레드에서 쓰이게 수정 필요.


        //넣어줄변수.setText(db.todoDao().getAll().toString());

        /*
        findViewById(R.id.add_button).setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View view){
               db.todoDao().insert(new Todo(넣어줄 내용));
               넣어줄변수.setText(db.todoDao().getAll().toString());
           }
        });

        };*/

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, view_small_goal_data);
        listView2.setAdapter(adapter);


        btn_plus_small_goal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //소목표 5개 입력받아서 리스트에 저장하는 소목표 추가 버튼 부분
                if(et_small_goal.getText().toString().isEmpty()||et_small_goal.getText().toString().length()==0)
                {
                    Toast.makeText(getApplicationContext(),"소목표를 작성해주세요.",Toast.LENGTH_SHORT).show();
                } //소목표 작성 칸에 아무것도 적지 않았을 경우인데 수정 필요!
                else{
                    if(small_goal_data.size()<=4) //원래 5인줄 알았는데 4를 입력해야 5개까지 입력됨.
                    {
                        String str = et_small_goal.getText().toString();
                        small_goal_data.add(str);

                        view_small_goal_data.add(small_goal_data.size()+"단계 : "+str);

                        et_small_goal.setText(" "); //입력한 값은 지워줘야지
                        adapter.notifyDataSetChanged();
                    }

                    else if(small_goal_data.size()>4)
                    {
                        Toast.makeText(getApplicationContext(),"소목표는 최대 5개까지 입력 가능합니다.",Toast.LENGTH_SHORT).show();
                    } // 5개 이상 입력 시 제한문구 나옴.
                }
            }
        }); //소목표 추가 버튼


        btn_del_small_goal.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count, checked ;
                count = adapter.getCount() ;

                if (count > 0) {
                    // 현재 선택된 아이템의 position 획득.
                    checked = listView2.getCheckedItemPosition();

                    if (checked > -1 && checked < count) {
                        // 아이템 삭제
                        small_goal_data.remove(checked) ;
                        view_small_goal_data.remove(checked);

                        // listview 선택 초기화.
                        listView2.clearChoices();

                        // listview 갱신.
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        }); //소목표 삭제 버튼


        btn_save_goal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(et_big_goal.getText().toString().isEmpty()||et_big_goal.getText().toString().length()==0)
                {
                    Toast.makeText(getApplicationContext(),"대목표를 작성해주세요.",Toast.LENGTH_SHORT).show();
                } //대목표 작성 칸에 아무것도 적지 않았을 경우인데 수정 필요!
                else if(small_goal_data.isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"소목표를 작성해주세요.",Toast.LENGTH_SHORT).show();
                }
                else
                    {
                        db.todoDao().insert(new Todo(et_big_goal.getText().toString(), small_goal_data));
                        Log.e("들어간 목표:",db.todoDao().getAll().toString());

                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.putExtra("big_goal_name",et_big_goal.getText().toString());
                        intent.putStringArrayListExtra("small_goal_name",small_goal_data);

                        startActivity(intent);
                        finish();
                        //Listviewitem goal1_name = new Listviewitem(et_big_goal.getText().toString()); //대목표 이름이 들어간 리스트 생성
                    }
            }
        }); // 목표 저장 버튼을 통해 이름이 대목표이고 소목표 리스트를 담은 리스트를 생성해야 함. 그리고 메인액티비티로 넘겨줘서 메인화면에서 보여야 함.




    } // oncreate()
}