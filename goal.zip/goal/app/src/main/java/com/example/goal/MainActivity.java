package com.example.goal;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    ArrayList<String > data = new ArrayList<>();

    Button btn_make_goal;
    Button btn_del_goal;

    private int list_res = android.R.layout.simple_list_item_1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        final AppDatabase db = Room.databaseBuilder(this, AppDatabase.class, "Goal_db")
                .allowMainThreadQueries().build();
        //allowMainThreadQueries()는 메인스레드에서 강제로 작동하게 해줌. 나중엔 백그라운드 스레드에서 쓰이게 수정 필요.

        ListView listView = (ListView) findViewById(R.id.listview_goal);
        btn_make_goal = findViewById(R.id.btn_make_goal);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        //처음화면
        //getSupportFragmentManager().beginTransaction().add(R.id.main_frame, new CompleteGoal()).commit();

        //FrameLayout에 fragment.xml 띄우기
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId() == R.id.goal_ing){
                    Intent intent = new Intent(MainActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else if(menuItem.getItemId() == R.id.goal_complete){
                    Intent intent = new Intent(MainActivity.this,CompleteGoal.class);
                    startActivity(intent);
                    finish();
                }
                if(menuItem.getItemId() == R.id.setting){
                    Intent intent = new Intent(MainActivity.this,Setting.class);
                    startActivity(intent);
                    finish();
                }

                /*switch (menuItem.getItemId()) {
                    //item을 클릭시 id값을 가져와 FrameLayout에 fragment.xml띄우기
                    case R.id.goal_ing:
                        Intent intent = new Intent(MainActivity.this,MainActivity.class);
                        startActivity(intent);
                        //getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new CompleteGoal()).commit();
                        break;
                    case R.id.goal_complete:
                        Intent intent = new Intent(MainActivity.this,CompleteGoal.class);
                        startActivity(intent);
                        //getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new CompleteGoal()).commit();
                        break;
                    case R.id.setting:
                        Intent intent = new Intent(MainActivity.this,CompleteGoal.class);
                        startActivity(intent);
                        //getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new CompleteGoal()).commit();
                        break;
                }*/
                return true; }
        });


        btn_make_goal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MakeGoal.class);
                startActivity(intent);
            }
        });

        Intent intent = getIntent();
        String goal1_name = intent.getStringExtra("big_goal_name");
        ArrayList<String> small_goal_name = intent.getStringArrayListExtra("small_goal_name");

        //String goal1 = goal1_name;

        if(db.todoDao().getAll().size()==0)
        {
            TextView msg_plus_goal = findViewById(R.id.msg_plus_goal);
            msg_plus_goal.setText("목표를 추가해주세요!");
        }

        else if(db.todoDao().getAll().size()!=0)
        {
            for(int i=0; i<db.todoDao().getAll().size(); i++)
            {
                data.add(db.todoDao().getAll().get(i).getBig_Goal());
            }


            for(int i=0; i<db.todoDao().getAll().size(); i++) {
                Log.e("onCreate: findAll() : ", String.valueOf(db.todoDao().getAll().get(i).getId())); //1~
                Log.e("onCreate: findAll() : " ,db.todoDao().getAll().get(i).getBig_Goal()); //id 숫자에 맞는 대목표
                Log.e("onCreate: findAll() : " ,String.valueOf(db.todoDao().getAll().get(i).getSmall_Goal())); //id 숫자에 맞는 소목표
                Log.e("onCreate: findAll() : ",String.valueOf(db.todoDao().getAll().get(i).getStage()));
            }


        }


        final TextView selected_goal = findViewById(R.id.selected_goal);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l){
                String data = (String) adapterView.getItemAtPosition(position);

                if(goal1_name!=null)
                {
                    selected_goal.setText("마지막으로 본 목표: "+data);
                }

                //Intent intent = new Intent(MainActivity.this, ContentActivity.class); //잠시 보류
                Log.e("데이터 사이즈",String.valueOf(db.todoDao().getAll().get(position).getSmall_Goal().size()));

                if(db.todoDao().getAll().get(position).getSmall_Goal().size() == 5){
                    Intent intent = new Intent(MainActivity.this,TestContent.class);
                    intent.putExtra("Key",data);
                    intent.putExtra("position",position);
                    intent.putStringArrayListExtra("small_goal_name",small_goal_name);
                    startActivity(intent);
                }
                else if(db.todoDao().getAll().get(position).getSmall_Goal().size() != 5){
                    //Toast.makeText(getApplicationContext(),"만들고 있숨다.",Toast.LENGTH_SHORT).show();
                    Log.e("아직 만들고 있어서 대체화면 보여줄거야","ㅇㅋ?");
                    Intent intent = new Intent(MainActivity.this, ContentActivity.class);
                    intent.putExtra("Key",data);
                    intent.putExtra("position",position);
                    intent.putStringArrayListExtra("small_goal_name",small_goal_name);
                    startActivity(intent);
                }

                //intent.putExtra("Key",data);
                //intent.putExtra("position",position);
                //intent.putStringArrayListExtra("small_goal_name",small_goal_name);
                //startActivity(intent);
                //finish();


            }
        }); //리스트 클릭하면 대목표 이름 보여줌. 대목표, 소목표를 담고 있는 창을 띄우도록 수정해야 함.


        ArrayAdapter adapter = new ArrayAdapter(this, list_res, data);
        listView.setAdapter(adapter);

        btn_del_goal = findViewById(R.id.del_goal);
        btn_del_goal.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {

                int count, checked ;
                count = adapter.getCount() ;

                //db.todoDao().delete(new Todo(db.todoDao().getAll().toString()));
                /*
                if (count > 0) {
                    // 현재 선택된 아이템의 position 획득.
                    checked = listView.getCheckedItemPosition();

                    if (checked > -1 && checked < count) {
                        // 아이템 삭제
                        data.remove(checked) ;

                        // listview 선택 초기화.
                        listView.clearChoices();

                        // listview 갱신.
                        adapter.notifyDataSetChanged();
                    }
                }*/
            }
        }) ;



    } //oncreate()

    @Override
    public void onBackPressed() {   // 뒤로가기 누르면 다이얼로그 생성
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("종료할까요?"); // 다이얼로그 제목
        builder.setCancelable(false);   // 다이얼로그 화면 밖 터치 방지
        builder.setPositiveButton("예", new AlertDialog.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                exit();
            }
        });

        builder.setNegativeButton("아니요", new AlertDialog.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"잘 생각했어요!",Toast.LENGTH_SHORT).show();
            }
        });

        builder.show(); // 다이얼로그 보이기
    }

    public void exit() { // 종료
        super.onBackPressed();
    }




}//MainActivity.class