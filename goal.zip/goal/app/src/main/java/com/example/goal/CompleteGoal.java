package com.example.goal;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class CompleteGoal extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_complete_goal);

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId() == R.id.goal_ing){
                    Intent intent = new Intent(CompleteGoal.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else if(menuItem.getItemId() == R.id.goal_complete){
                    Intent intent = new Intent(CompleteGoal.this,CompleteGoal.class);
                    startActivity(intent);
                    finish();
                }
                if(menuItem.getItemId() == R.id.setting){
                    Intent intent = new Intent(CompleteGoal.this,Setting.class);
                    startActivity(intent);
                    finish();
                }
                return true; }
        });


    } //oncreate

    @Override
    public void onBackPressed() {   // 뒤로가기 누르면 다이얼로그 생성
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("종료할까요?"); // 다이얼로그 제목
        builder.setCancelable(false);   // 다이얼로그 화면 밖 터치 방지
        builder.setPositiveButton("예", new AlertDialog.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                exit();
            }
        });

        builder.setNegativeButton("아니요", new AlertDialog.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"잘 생각했어요!",Toast.LENGTH_SHORT).show();
            }
        });

        builder.show(); // 다이얼로그 보이기
    }

    public void exit() { // 종료
        super.onBackPressed();
    }
}