package com.example.goal;

public class Listviewitem {

    private String name;
    public String getName(){return name;}
    public Listviewitem(String name){
        this.name=name;
    }
}