package com.example.goal;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.ArrayList;

public class TestContent extends AppCompatActivity {


    private int stage = 0;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.small_goal_5);

        AlertDialog.Builder oDialog = new AlertDialog.Builder(this,
                android.R.style.Theme_DeviceDefault_Light_Dialog);


        TextView textView_Big = findViewById(R.id.view_big_goal);
        TextView textView_Small = findViewById(R.id.view_small_goal);
        ImageView small_goal1 = findViewById(R.id.smallgoal1);
        ImageView small_goal2 = findViewById(R.id.smallgoal2);
        ImageView small_goal3 = findViewById(R.id.smallgoal3);
        ImageView small_goal4 = findViewById(R.id.smallgoal4);
        ImageView small_goal5 = findViewById(R.id.smallgoal5);
        ImageView user1 = findViewById(R.id.user1);
        ImageView user2 = findViewById(R.id.user2);
        ImageView user3 = findViewById(R.id.user3);
        ImageView user4 = findViewById(R.id.user4);
        ImageView user5 = findViewById(R.id.user5);
        ImageView user_good = findViewById(R.id.user_good);
        Button completeGoal = findViewById(R.id.completeGoal);
        Button move_completeGoal = findViewById(R.id.move_completeGoal);



        user2.setVisibility(View.INVISIBLE);
        user3.setVisibility(View.INVISIBLE);
        user4.setVisibility(View.INVISIBLE);
        user5.setVisibility(View.INVISIBLE);
        user_good.setVisibility(View.INVISIBLE);

        move_completeGoal.setEnabled(false);


        final AppDatabase db = Room.databaseBuilder(this, AppDatabase.class, "Goal_db")
                .allowMainThreadQueries().build();
        //allowMainThreadQueries()는 메인스레드에서 강제로 작동하게 해줌. 나중엔 백그라운드 스레드에서 쓰이게 수정 필요.

        Intent intent = getIntent();
        int position = intent.getExtras().getInt("position");
        ArrayList<String> small_goal_data = db.todoDao().getAll().get(position).getSmall_Goal();

        textView_Big.setText(db.todoDao().getAll().get(position).getBig_Goal());
        textView_Small.setText("현재 1단계 :\n"+small_goal_data.get(0)+"\n를(을) 진행하고 있습니다!");

        small_goal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //small_ing.setText(small_goal_data.get(0));
                Toast.makeText(getApplicationContext(),String.valueOf(small_goal_data.get(0)),Toast.LENGTH_SHORT).show();
            }
        });

        small_goal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),String.valueOf(small_goal_data.get(1)),Toast.LENGTH_SHORT).show();
            }
        });

        small_goal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),String.valueOf(small_goal_data.get(2)),Toast.LENGTH_SHORT).show();
            }
        });

        small_goal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),String.valueOf(small_goal_data.get(3)),Toast.LENGTH_SHORT).show();
            }
        });

        small_goal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),String.valueOf(small_goal_data.get(4)),Toast.LENGTH_LONG).show();
            }
        });



        completeGoal.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                oDialog.setMessage("["+small_goal_data.get(stage)+"]를(을) 달성하고 다음 단계로 넘어가시겠습니까?")
                        .setPositiveButton("싫어요!", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                Log.e("Dialog", "취소");
                                Toast.makeText(getApplicationContext(), "취소", Toast.LENGTH_LONG).show();
                            }
                        })
                        .setNeutralButton("네 넘어가요!", new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                if(stage !=5)
                                {
                                    stage+=1;
                                }
                                else if(stage ==5)
                                {
                                    stage =5;
                                }

                                if(stage ==1)
                                {
                                    user1.setVisibility(View.INVISIBLE);
                                    user2.setVisibility(View.VISIBLE);
                                    textView_Small.setText("현재 "+(stage+1)+"단계 :\n"+small_goal_data.get(stage)+"\n를(을) 진행하고 있습니다!");
                                }
                                else if(stage == 2)
                                {
                                    user2.setVisibility(View.INVISIBLE);
                                    user3.setVisibility(View.VISIBLE);
                                    textView_Small.setText("현재 "+(stage+1)+"단계 :\n"+small_goal_data.get(stage)+"\n를(을) 진행하고 있습니다!");
                                }
                                else if(stage == 3)
                                {
                                    user3.setVisibility(View.INVISIBLE);
                                    user4.setVisibility(View.VISIBLE);
                                    textView_Small.setText("현재 "+(stage+1)+"단계 :\n"+small_goal_data.get(stage)+"\n를(을) 진행하고 있습니다!");
                                }
                                else if(stage == 4)
                                {
                                    user4.setVisibility(View.INVISIBLE);
                                    user5.setVisibility(View.VISIBLE);
                                    textView_Small.setText("현재 "+(stage+1)+"단계 :\n"+small_goal_data.get(stage)+"\n를(을) 진행하고 있습니다!");
                                }
                                else if(stage ==5)
                                {
                                    Toast.makeText(getApplicationContext(),"목표를 다 이뤘어요!!",Toast.LENGTH_SHORT).show();
                                    user5.setVisibility(View.INVISIBLE);
                                    user_good.setVisibility(View.VISIBLE);
                                    textView_Small.setText("모든 단계를 완료했습니다! 짱짱");
                                    completeGoal.setEnabled(false);
                                    move_completeGoal.setEnabled(true);
                                }
                            }
                        })
                        .setCancelable(false) // 백버튼으로 팝업창이 닫히지 않도록 한다.

                        .show();

            }
        }) ;

    } //oncreate
}
