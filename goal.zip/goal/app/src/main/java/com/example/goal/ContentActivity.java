package com.example.goal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.ArrayList;

public class ContentActivity extends AppCompatActivity {

    ArrayList<String> data2 = new ArrayList<>();

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_content);

        final AppDatabase db = Room.databaseBuilder(this, AppDatabase.class, "Goal_db")
                .allowMainThreadQueries().build();
        //allowMainThreadQueries()는 메인스레드에서 강제로 작동하게 해줌. 나중엔 백그라운드 스레드에서 쓰이게 수정 필요.

        TextView textView1 = (TextView) findViewById(R.id.big_goal_name);
        ListView listView3 = (ListView) findViewById(R.id.small_goal_name);

        Intent intent = getIntent();
        int position = intent.getExtras().getInt("position");
        ArrayList<String> small_goal_data = db.todoDao().getAll().get(position).getSmall_Goal();

        for(String i : small_goal_data)

        {
            String small = i;
            data2.add(small);
        }
        textView1.setText(db.todoDao().getAll().get(position).getBig_Goal());

        ArrayAdapter content_Adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, data2);
        listView3.setAdapter(content_Adapter);

    }
}